# CA1-DAAA2B02-2112589-LimHur
This project aims to predict insurance premium costs given a person's general health!